import java.io.File;
import java.io.IOException;

/**
 * build a VM translator using:
 * Parser to run through a given .vm file
 * CodeWriter to check each line and translate it to hack assembly code
 * 
 * @param file of .vm type
 *             outputs a .asm file in the same folder as the source file (with
 *             the same name)
 */
public class VMTranslator {
    public static void main(String[] args) {
        Parser parser = new Parser(new File(args[0]));
        String path = args[0].replace(".vm", ".asm");
        CodeWriter writer = new CodeWriter(new File(path));
        String type;// command type
        while (parser.hasMoreLines()) {
            parser.advance();
            type = parser.commandType();
            if (type == "push" || type == "pop") {
                writer.WritePushPop(type, parser.arg1(), parser.arg2());
            }
            if (type == "arithmetic") {
                writer.WriteArithmetic(parser.currentLine);
                CodeWriter.symbolCount++;
            }
        }
        try {
            writer.close();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}
