import java.io.FileWriter;
import java.io.IOException;
import java.io.BufferedWriter;
import java.io.File;

public class HackAssembler {
    SymbolTable symbolTable;
    Parser parser;
    BufferedWriter writer;

    /**
     * build an Hack Assembler
     * translates Hack Assembly program to machine language
     * 
     * @param source file which is .asm file
     * @param target file which is going to be .hack file
     */
    public HackAssembler(File source, File target) {
        try {
            this.symbolTable = new SymbolTable();
            this.parser = new Parser(source);
            Code.initialize();
            this.writer = new BufferedWriter(new FileWriter(target));
        } catch (IOException e) {
            e.printStackTrace();
        }

    }

    public void translator(File source) {// activate translation
        firstPass();
        secondPass(source);
    }

    // Reads the program lines, one by one focusing only on (label) declarations
    // adds the symbols to the symbolTable according to their line appearance
    public void firstPass() {

        while (parser.hasMoreLines()) {
            parser.advance();
            while (parser.hasMoreLines() && parser.instructionType() != "L") {// run until L instruct found
                parser.advance();

            }
            if (!symbolTable.contains(parser.currentLine)) {// check if not already in the table
                symbolTable.addEntry(parser.symbol(), Parser.lineCount);
            }

        }
        try {// close the file
            this.parser.reader.close();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    // Parses the A and C instructions and adds it to the new file as 16 bit binary
    // code
    public void secondPass(File source) {
        int address;
        String binaryAddress, instruct;
        try {
            this.parser = new Parser(source);// open the file again

            while (parser.hasMoreLines()) {
                parser.advance();
                if (parser.instructionType() == "A") {// A instruction

                    if (!Character.isDigit(parser.currentLine.charAt(1))) {// case of varibale symbol
                        if (!symbolTable.contains(parser.symbol())) {// new varibale symbol
                            symbolTable.addEntry(parser.symbol(), SymbolTable.countVar);// place in the next free
                                                                                        // address
                            SymbolTable.countVar++;
                        }
                        address = symbolTable.getAddress(parser.symbol());

                    } else {// regular A intruction
                        address = Integer.parseInt(parser.symbol());// convert string to int
                    }
                    binaryAddress = (Integer.toBinaryString(address));// convert int to binary
                    writer.write(String.format("%16s", binaryAddress).replaceAll(" ", "0") + "\n");

                } else {
                    if (parser.instructionType() == "C") {// C instruction
                        String comp = Code.comp(parser.comp());
                        String dest = Code.dest(parser.dest());
                        String jump = Code.jump(parser.jump());
                        // build the 16 bit String
                        instruct = "111" + comp + dest + jump;
                        writer.write(instruct + "\n");

                    }
                }
            }
            writer.close();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

}
